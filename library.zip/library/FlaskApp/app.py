from flask import Flask, request, render_template, redirect, url_for
import zeep

app = Flask(__name__)
wsdl = 'http://localhost:8090/book-service?wsdl'  # URL to your SOAP service WSDL
client = zeep.Client(wsdl=wsdl)

@app.route('/', methods=['GET', 'POST'])
def index():
    # Search functionality
    search_title = request.args.get('search_title')
    all_books = []

    # Handling POST request for adding a new book
    if request.method == 'POST' and 'add_book' in request.form:
        id = request.form.get('id')
        title = request.form.get('title')
        author = request.form.get('author')
        publication_date = request.form.get('publication_date')
        genre = request.form.get('genre')
        description = request.form.get('description')
        price = request.form.get('price')
        availability = request.form.get('availability')
        client.service.addBook({'id': id, 'title': title, 'author': author, 'publicationDate': publication_date,
                                'genre': genre, 'description': description, 'price': price, 'availability': availability})

    # Search for a book by title if a search query is provided
    if search_title:
        book = client.service.getBookByTitle(search_title)
        if book:
            all_books.append(book)
    else:
        # Fetch all books for listing if no search query is provided
        all_books = client.service.getAllBooks()

    return render_template('index.html', books=all_books)


@app.route('/update_book/<int:id>', methods=['GET'])
def render_update_page(id):
    book = client.service.getBookById(id)
    return render_template('update.html', book=book)


@app.route('/update_book/<int:id>', methods=['POST'])
def update_book(id):
    title = request.form.get('title')
    author = request.form.get('author')
    publication_date = request.form.get('publication_date')
    genre = request.form.get('genre')
    description = request.form.get('description')
    price = request.form.get('price')
    availability = request.form.get('availability')
    client.service.updateBook({'id': id, 'title': title, 'author': author, 'publicationDate': publication_date,
                               'genre': genre, 'description': description, 'price': price, 'availability': availability})
    return redirect(url_for('index'))

@app.route('/delete_book/<int:id>', methods=['POST'])
def delete_book(id):
    client.service.deleteBook(id)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
