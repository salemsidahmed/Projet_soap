package org.example.service;

import org.example.model.Book;

import jakarta.jws.WebMethod;
import jakarta.jws.WebService;
import java.util.List;

@WebService
public interface BookService {

    @WebMethod
    void addBook(Book book);

    @WebMethod
    void updateBook(Book book);

    @WebMethod
    void deleteBook(int id);

    @WebMethod
    Book getBookById(int id);

    @WebMethod
    List<Book> getAllBooks();
}
