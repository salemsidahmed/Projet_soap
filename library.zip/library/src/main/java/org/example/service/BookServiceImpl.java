package org.example.service;

import org.example.dao.BookDAO;
import org.example.dao.BookDAOImpl;
import org.example.model.Book;

import jakarta.jws.WebService;
import java.util.List;

@WebService(endpointInterface = "org.example.service.BookService")
public class BookServiceImpl implements BookService {

    private final BookDAO bookDAO = new BookDAOImpl();

    @Override
    public void addBook(Book book) {
        bookDAO.addBook(book);
    }

    @Override
    public void updateBook(Book book) {
        bookDAO.updateBook(book);
    }

    @Override
    public void deleteBook(int id) {
        bookDAO.deleteBook(id);
    }

    @Override
    public Book getBookById(int id) {
        return bookDAO.getBookById(id);
    }

    @Override
    public List<Book> getAllBooks() {
        return bookDAO.getAllBooks();
    }
}
