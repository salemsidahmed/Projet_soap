
package org.example.service;
 import jakarta.xml.ws.Endpoint;
 import org.example.dao.BookDAO;
 import org.example.dao.BookDAOImpl;

public class BookServicePublisher {
    public static void main(String[] args) {
        // Specify the URL for publishing the service
        String url = "http://localhost:8090/book-service";

        // Create an instance of the service implementation
        //BookDAO bookDAO = new BookDAOImpl(); // Assuming BookDAO implementation
        BookService bookService = new BookServiceImpl();

        // Publish the service
        Endpoint.publish(url, bookService);

        // Print confirmation
        System.out.println("BookService is published at " + url);
    }
}
