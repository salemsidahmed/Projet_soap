package org.example;

import org.example.dao.BookDAO;
import org.example.dao.BookDAOImpl;
import org.example.model.Book;

import java.math.BigDecimal;
import java.sql.Date; // Import java.sql.Date
import java.util.List;

public class Main {

    public static void main(String[] args) {
        // Instantiate BookDao
        BookDAO bookDao = new BookDAOImpl();

        // Test adding a book
        Book newBook = new Book(
                "Java Programming",
                "John Doe",
                new Date(2022 - 1900, 0, 1), // Adjusted date creation using java.sql.Date
                "Programming",
                "A comprehensive guide to Java programming.",
                BigDecimal.valueOf(29.99),
                true
        );
        bookDao.addBook(newBook);
        System.out.println("Book added: " + newBook);

        // Test getting a book by ID
        Book retrievedBook = bookDao.getBookById(newBook.getId());
        if (retrievedBook != null) {
            System.out.println("Retrieved book by ID: " + retrievedBook);
            // Test updating a book
            retrievedBook.setPrice(BigDecimal.valueOf(39.99));
            bookDao.updateBook(retrievedBook);
            System.out.println("Book updated: " + retrievedBook);
        } else {
            System.out.println("No book found with ID: " + newBook.getId());
        }

        // Test getting all books
        List<Book> allBooks = bookDao.getAllBooks();
        System.out.println("All books:");
        for (Book book : allBooks) {
            System.out.println(book);
        }

        // Test deleting a book
        if (retrievedBook != null) {
            bookDao.deleteBook(retrievedBook.getId());
            System.out.println("Book deleted: " + retrievedBook.getId());
        } else {
            System.out.println("No book found to delete.");
        }
    }
}
