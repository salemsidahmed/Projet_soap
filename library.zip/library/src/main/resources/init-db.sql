CREATE DATABASE IF NOT EXISTS library;

USE library;

CREATE TABLE IF NOT EXISTS book (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    publication_date DATE,
    genre VARCHAR(100),
    description TEXT,
    price DECIMAL(10, 2),
    availability BOOLEAN DEFAULT TRUE
);
